using System.Collections;
using System.Collections.Generic;
using System.IO;
using UnityEngine;

public class CameraManager : MonoBehaviour
{
    public string filePath = "Assets/Screenshots/";
    public List<Camera> cameras = new List<Camera>();
    // Start is called before the first frame update
    void Start()
    {
        
        
    }

    // Update is called once per frame
    void Update()
    {
       
    }
    public void UpdateCameraList()
    {
        cameras.Clear();

        // Find all Camera components in the children
        FindCamerasInChildren(transform);
    }
    public void TakePictures()
    {
        foreach (Camera c in cameras)
        {
            TakePicture(c);
        }
    }

    private void TakePicture(Camera camera)
    {
        if (camera == null)
        {
            Debug.LogError("No Camera Provided for CameraIO");
        }

        string fullPath = filePath + camera.name + ".png";
        // Create a RenderTexture with the same dimensions as the screen
        RenderTexture renderTexture = new RenderTexture(Screen.width, Screen.height, 24);
        camera.targetTexture = renderTexture;

        // Render the camera's view to the RenderTexture
        camera.Render();

        // Activate the RenderTexture
        RenderTexture.active = renderTexture;

        // Create a Texture2D to store the pixels from the RenderTexture
        Texture2D screenshot = new Texture2D(Screen.width, Screen.height, TextureFormat.RGB24, false);
        screenshot.ReadPixels(new Rect(0, 0, Screen.width, Screen.height), 0, 0);
        screenshot.Apply();

        // Deactivate the RenderTexture and reset the target texture
        RenderTexture.active = null;
        camera.targetTexture = null;

        // Convert the Texture2D to PNG
        byte[] bytes = screenshot.EncodeToPNG();

        // Ensure the directory exists
        string directory = Path.GetDirectoryName(fullPath);
        if (!Directory.Exists(directory))
        {
            Directory.CreateDirectory(directory);
        }

        // Save the PNG to the specified file path
        File.WriteAllBytes(fullPath, bytes);

        //Debug.Log("Screenshot saved to: " + fullPath);

        // Clean up
        Destroy(renderTexture);
        Destroy(screenshot);
    }

    void FindCamerasInChildren(Transform parent)
    {
        // Iterate through each child of the parent Transform
        foreach (Transform child in parent)
        {
            // Check if the child has a Camera component
            Camera camera = child.GetComponent<Camera>();
            if (camera != null)
            {
                // Add the Camera component to the list
                cameras.Add(camera);
            }

            // Recursively call this method to check the child's children
            FindCamerasInChildren(child);
        }
    }
}
