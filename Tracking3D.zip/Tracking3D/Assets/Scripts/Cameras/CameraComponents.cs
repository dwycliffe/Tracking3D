using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class CameraComponents : MonoBehaviour
{
    public GameObject hideParent;
    public GameObject cameraModel;
    public TextMeshProUGUI text;
    public Material defaultMat;
    public Material activeMat;
    // Start is called before the first frame update
    void Start()
    {
        text.text = gameObject.name;
        text.transform.LookAt(Camera.main.transform);
        text.transform.eulerAngles = new Vector3(text.transform.eulerAngles.x, text.transform.eulerAngles.y + 180, text.transform.eulerAngles.z);
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void UpdateMaterial(bool isActive)
    {
        if(isActive)
        {
            ApplyMaterialToGameObjectAndChildren(cameraModel, activeMat);
        }
        else
        {
            ApplyMaterialToGameObjectAndChildren(cameraModel, defaultMat);
        }
    }

    void ApplyMaterialToGameObjectAndChildren(GameObject obj, Material mat)
    {
        // Apply material to the current game object
        Renderer renderer = obj.GetComponent<Renderer>();
        if (renderer != null)
        {
            renderer.material = mat;
        }

        // Recursively apply material to all children
        foreach (Transform child in obj.transform)
        {
            ApplyMaterialToGameObjectAndChildren(child.gameObject, mat);
        }
    }
}
