using System.Collections;
using System.Collections.Generic;
using MathNet.Numerics.LinearAlgebra;
using MathNet.Numerics.LinearAlgebra.Double;
using UnityEngine;

public class CameraParameters : MonoBehaviour
{
    public Camera camera;
    public Matrix4x4 projectionMatrix;
    public Matrix<double> K;
    public Vector3 position;
    public Vector3 rotation;
    public Vector2 principalPoint;
    public float focalLength; //https://docs.unity3d.com/ScriptReference/Camera-focalLength.html
    public float focalLengthPixels;
    public Vector2 f;
    // Start is called before the first frame update
    void Start()
    {
        position = transform.position;
        rotation = transform.rotation.eulerAngles;
        focalLength = camera.focalLength / 1000f;
        //See about camera intrinsic matrix 

        float verticalFOV = camera.fieldOfView;
        int resolutionHeight = camera.pixelHeight;
        Vector2 sensorSize = camera.sensorSize;
        focalLengthPixels = (resolutionHeight * sensorSize.y) /
            (2 * sensorSize.y *  Mathf.Tan(verticalFOV * Mathf.Deg2Rad / 2));

        float fx = sensorSize.x / (2 * Mathf.Tan(verticalFOV * Mathf.Deg2Rad / 2));
        float fy = sensorSize.y / (2 * Mathf.Tan(verticalFOV * Mathf.Deg2Rad / 2));
        f = new Vector2(fx, fy);
        focalLength = fx;
        //Debug.Log("Focal Length in Pixels: " + f);

        //https://forum.unity.com/threads/finding-principal-point-based-on-unitys-camera-parameters.1373616/
        float pX = Screen.width / 2;
        float pY = Screen.height / 2;
        principalPoint = new Vector2(pX, pY);
        // Output the results
        double[,] k = new double[,]
        {
            { focalLength, 0.0, pX},
            { 0.0, focalLength, pY},
            { 0.0, 0.0, 1.0 }
        };
        K = DenseMatrix.OfArray(k);

    }

    // Update is called once per frame
    void Update()
    {
        
    }


    public Matrix<double> GetRelativeProjectionMatrix(Camera otherCam)
    {
        GameObject otherGO = otherCam.gameObject;
        Vector3 otherPos = otherGO.transform.position;
        Vector3 otherRot = otherGO.transform.rotation.eulerAngles;

        Vector3 t = transform.position - otherPos;
        Vector3 r = transform.rotation.eulerAngles - otherRot;

        double[,] k = new double[,]
        {
            { r.x, 0.0, 0.0, t.x},
            { 0.0, r.y, 0.0, t.y},
            { 0.0, 0.0, r.z, t.z}
        };

        Matrix<double> Rt = DenseMatrix.OfArray(k);

        return K * Rt;

    }

   


}
