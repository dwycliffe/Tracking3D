using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class UIManager : MonoBehaviour
{
    // UI 
    public GameObject takePictureParent;
    public Button takePictureButton;
    public GameObject maskParent;
    public GameObject maskButton;

    public GameObject visGO;
    public Image visualization;
    // Logic
    public CameraManager cameraManager;
    public ImageProcessing imageProcessor;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void TakePicture()
    {
        cameraManager.TakePictures();
        maskParent.SetActive(true);
        takePictureButton.interactable = false;
    }

    public void CreateMask()
    {
        visGO.SetActive(true);
        imageProcessor.ProcessCameraImages();
        
    }
}
