using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.IO;
using UnityEngine.UI;
using MathNet.Numerics.LinearAlgebra;
using MathNet.Numerics.LinearAlgebra.Double;



public class ImageProcessing : MonoBehaviour
{
    public CameraManager cameraManager;
    public Image maskView;
    public Dictionary<string, Vector2> coords = new Dictionary<string, Vector2>();
    private Vector2 coord = new Vector2();
    public Dictionary<string, Vector3> estimates = new Dictionary<string, Vector3>();
    public GameObject target;
    public GameObject estimate;

    public Dictionary<Color, int> colorCounter = new Dictionary<Color, int>();

    private Vector2 noTarget = new Vector2(-1, -1);
    // Start is called before the first frame update
    void Start()
    {
        //cameraManager.UpdateCameraList();
        //cameraManager.TakePictures();
        //ProcessCameraImages();
    }

    public void ProcessCameraImages()
    {
        foreach (Camera cam in cameraManager.cameras)
        {
            string imagePath = cameraManager.filePath + cam.name + ".png";
            string maskPath = cameraManager.filePath + "/Masks/" + cam.name + ".png";
            CreateMask(imagePath, maskPath);
            coords[cam.name] = new Vector2(coord.x, coord.y);
        }

        // Reset estimates so that only cameras with targets return a prediction
        estimates = new Dictionary<string, Vector3>();
        for (int i = 1; i < cameraManager.cameras.Count; i++)
        {
  
            Camera c1 = cameraManager.cameras[i - 1];
            Camera c2 = cameraManager.cameras[i];
            //There was not a target found in one of the cameras - no triangulation
            if(NoTarget(c1, c2))
            {
                Debug.Log(c1.name + " or " + c2.name + " did not have a target");
                continue;
            }
            estimates["RAY_" + c1.name + "_" + c2.name] = RayIntersection(c1, c2);
        }
        //Debug.Log("Location ACTUAL: " + target.transform.position);
        //foreach (KeyValuePair<string, Vector3> entry in estimates)
        //{
        //    Debug.Log(entry.Key + " estimate: " + entry.Value + " distance: " + Vector3.Distance(target.transform.position, entry.Value));
        //}
    }

    public bool NoTarget(Camera c1, Camera c2)
    {
        return coords[c1.name] == noTarget || coords[c2.name] == noTarget;
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public Vector3 RayIntersection(Camera c1, Camera c2)
    {
        Vector2 p1 = coords[c1.name];
        Vector2 p2 = coords[c2.name];

        Ray r1 = c1.ScreenPointToRay(p1);
        Ray r2 = c2.ScreenPointToRay(p2);

        Vector3 intersectionPoint = GetClosestPointOnTwoLines(r1.origin, r1.direction, r2.origin, r2.direction);

        // Print the intersection point to the console
        //Debug.Log("Intersection Point: " + intersectionPoint);
        return intersectionPoint;

    }
    Vector3 GetClosestPointOnTwoLines(Vector3 p1, Vector3 d1, Vector3 p2, Vector3 d2)
    {
        // Line1: p1 + t1 * d1
        // Line2: p2 + t2 * d2
        // Find t1 and t2 such that the distance between the points on the lines is minimized
        Vector3 n = Vector3.Cross(d1, d2);
        Vector3 n1 = Vector3.Cross(d1, n);
        Vector3 n2 = Vector3.Cross(d2, n);

        float t1 = Vector3.Dot((p2 - p1), n2) / Vector3.Dot(d1, n2);
        float t2 = Vector3.Dot((p1 - p2), n1) / Vector3.Dot(d2, n1);

        Vector3 point1 = p1 + t1 * d1;
        Vector3 point2 = p2 + t2 * d2;

        // The intersection point is the midpoint of the closest points
        return (point1 + point2) / 2;
    }
   

    public Texture2D LoadImage(string filePath)
    {

        if (!File.Exists(filePath))
        {
            Debug.LogError(filePath + " - does not exist.");
            return null;
        }

        byte[] fileData = File.ReadAllBytes(filePath);
        //Texture2D texture = new Texture2D(2, 2);
        Texture2D texture = new Texture2D(Screen.width, Screen.height);
        if (texture.LoadImage(fileData))
        {
            return texture;
        }
        else
        {
            Debug.LogError("Failed to load texture from file.");
            return null;
        }
    }


    public Texture2D ProcessPixels(Texture2D texture)
    {
        Color[] pixels = texture.GetPixels();
        List<int> indices = new List<int>();
        // Initialize variables to calculate the center point
        int totalRedPixels = 0;
        float sumX = 0f;
        float sumY = 0f;

        Texture2D mask = new Texture2D(texture.width, texture.height);

        // Iterate through the pixels
        for (int y = 0; y < texture.height; y++)
        {
            for (int x = 0; x < texture.width; x++)
            {
                int index = y * texture.width + x;
                Color pixel = pixels[index];
                if (colorCounter.ContainsKey(pixel))
                {
                    colorCounter[pixel] += 1;
                }
                else
                {
                    colorCounter[pixel] = 1;
                }
                pixel = texture.GetPixel(x, y);

                // Check if the pixel is not white
                if (!IsWhite(pixel))//IsRed(pixel))
                {
                    indices.Add(index);
                    sumX += x;
                    sumY += y;
                    totalRedPixels++;
                    mask.SetPixel(x, y, Color.red);
                }
                else
                {
                    mask.SetPixel(x, y, Color.blue);
                }
            }
        }
        // Apply pixel changes
        mask.Apply();

        // Calculate the center point
        // The Y pixels are from the bottom up
        if (totalRedPixels > 0)
        {
            int centerX = (int)(sumX / totalRedPixels);
            //int centerY = (int)(texture.height - (sumY / totalRedPixels));
            int centerY = (int)(sumY / totalRedPixels);
            coord = new Vector2(centerX, centerY);
            //Debug.Log($"Center of red pixels: ({centerX}, {centerY})");
        }
        else
        {
            Debug.Log("No red pixels found!");
            coord = noTarget;
        }


        return mask;
    }


    public void CreateMask(string imagePath, string maskPath)
    {
        Texture2D original = LoadImage(imagePath);
        Texture2D mask = ProcessPixels(original);
        byte[] bytes = mask.EncodeToPNG();
        // Ensure the directory exists
        string directory = Path.GetDirectoryName(maskPath);
        if (!Directory.Exists(directory))
        {
            Directory.CreateDirectory(directory);
        }

        // Save the PNG to the specified file path
        File.WriteAllBytes(maskPath, bytes);
        maskView.sprite = Sprite.Create(mask, new Rect(0, 0, mask.width, mask.height), new Vector2(0.5f, 0.5f));
    }

   
    bool IsRed(Color color)
    {
        // Define a threshold for what is considered red
        return color.r > color.g + color.b;
    }


    bool IsWhite(Color color, float threshold = 0.1f)
    {
        // Define a threshold for what is considered white
        float avg = (color.r + color.b + color.g) / 3.0f;
        if (Mathf.Abs(color.r - avg) < threshold && Mathf.Abs(color.g - avg) < threshold && Mathf.Abs(color.r - avg) < threshold)
        {
            return true;
        }
        return false;
    }

    public Vector3 Triangulate(Camera c1, Camera c2)
    {
        float f1 = c1.GetComponent<CameraParameters>().focalLength;
        float f2 = c2.GetComponent<CameraParameters>().focalLength;
        f1 = c1.GetComponent<CameraParameters>().f.x;
        f2 = c2.GetComponent<CameraParameters>().f.x;

        Vector2 pp1 = c1.GetComponent<CameraParameters>().principalPoint;
        Vector2 pp2 = c2.GetComponent<CameraParameters>().principalPoint;


        Vector2 p1 = coords[c1.name];
        Vector2 p2 = coords[c2.name];

        // Extract R and T for both cameras
        var (R1, T1) = ExtractRT(c1);
        var (R2, T2) = ExtractRT(c2);

        Vector<double> q1 = DenseVector.OfArray(new double[]
        { p1.x - (pp1.x / f1), p1.y - (pp1.y / f1), 1 });
        Vector<double> q2 = DenseVector.OfArray(new double[]
        { p2.x - (pp2.x / f2), p2.y - (pp2.y / f2), 1 });

        Vector<double> r1_q1 = R1 * q1;
        Vector<double> r2_q2 = -R2 * q2;


        Matrix<double> A = DenseMatrix.OfColumns(new List<Vector<double>> { r1_q1, r2_q2 });
        Vector<double> b = T2 - T1;


        // Solve least squares
        Vector<double> x = A.TransposeThisAndMultiply(A).Inverse() * A.Transpose() * b;
        //Debug.Log("Least Squares Solution = " + x);

        Vector<double> p3D = DenseVector.OfArray(new double[]
        { q1[0] * x[0], q1[1] * x[0], x[0]});
        Vector3 point1_3D = new Vector3((float)(q1[0] * x[0]), (float)(q1[1] * x[0]), (float)(x[0]));
        Vector3 point2_3D = new Vector3((float)(q2[0] * x[0]), (float)(q2[1] * x[0]), (float)(x[0]));
        Vector3 avg = (point1_3D + point2_3D) / 2;

        //Debug.Log("C1 estimate: " + point1_3D + " C2 Estimate: " + point2_3D
        //+ "\nAVG: " + avg + " ACTUAL: " + target.transform.position);
        return avg;
    }

    static Matrix<double> ConcatenateHorizontally(Matrix<double> matrix1, Matrix<double> matrix2)
    {
        // Check if matrices have the same number of rows
        if (matrix1.RowCount != matrix2.RowCount)
        {
            Debug.Log("Matrices must have the same number of rows.");
        }
        List<Vector<double>> columns = new List<Vector<double>>();
        for (int i = 0; i < matrix1.ColumnCount; i++)
        {
            columns.Add(matrix1.Column(i));
        }
        for (int i = 0; i < matrix2.ColumnCount; i++)
        {
            columns.Add(matrix2.Column(i));
        }
        // Create a new matrix with combined columns
        return DenseMatrix.OfColumns(columns);
    }





    public Vector3 Calculate3DPoint(Camera c1, Camera c2)
    {


        Matrix<double> K1 = c1.GetComponent<CameraParameters>().K;
        Matrix<double> K2 = c2.GetComponent<CameraParameters>().K;
        Vector<double> point1 = DenseVector.OfArray(new double[] { coords[c1.name].x, coords[c1.name].y });
        Vector<double> point2 = DenseVector.OfArray(new double[] { coords[c2.name].x, coords[c2.name].y });

        Vector2 screenPoint1 = coords[c1.name];
        Vector2 screenPoint2 = coords[c1.name];
        // Extract R and T for both cameras
        var (R1, T1) = ExtractRT(c1);
        var (R2, T2) = ExtractRT(c2);

        Matrix<double> P1 = K1 * DenseMatrix.OfArray(new double[,]
        {
            { 1, 0, 0, 0 },
            { 0, 1, 0, 0 },
            { 0, 0, 1, 0 }
        });



        // Calculate relative R and T
        Matrix<double> R = R2 * R1.Transpose();
        Vector<double> T = T2 - (R * T1);



        //Debug.Log("Relative R: " + R);
        //Debug.Log("R * T = " + (R * T1));
        //Debug.Log("Relative T = " + T);

        Matrix<double> P2 = K2 * DenseMatrix.OfArray(new double[,]
        {
            { R[0, 0], R[0, 1], R[0, 2], T[0] },
            { R[1, 0], R[1, 1], R[1, 2], T[1] },
            { R[2, 0], R[2, 1], R[2, 2], T[2] }
        });

        //Debug.Log("Q1 = " + c1.transform.rotation +  "  R1=" + R1);
        //Debug.Log("T1=" + T1);
        //Debug.Log("P1=" + P1);
        //Debug.Log("Q2 = " + c2.transform.rotation + "  R2=" + R2);
        //Debug.Log("T2=" + T2);
        //Debug.Log("P2=" + P2);


        // Convert Euler angles to radians
        float angleX = 0f * Mathf.Deg2Rad;
        float angleY = -30f * Mathf.Deg2Rad;
        float angleZ = 0f * Mathf.Deg2Rad;

        // Create quaternion from Euler angles
        Quaternion quaternion = Quaternion.Euler(angleX, angleY, angleZ);

        // Convert quaternion to rotation matrix
        Matrix4x4 rotationMatrix4x4 = Matrix4x4.Rotate(quaternion);

        // Extract the upper-left 3x3 submatrix to get the rotation matrix

        // Print the rotation matrix
        //Debug.Log("Rotation Matrix:");
        //Debug.Log(rotationMatrix4x4);

        // Construct the A matrix
        Matrix<double> A = DenseMatrix.OfArray(new double[,]
        {
            { point1[0] * P1[2, 0] - P1[0, 0], point1[0] * P1[2, 1] - P1[0, 1], point1[0] * P1[2, 2] - P1[0, 2], point1[0] * P1[2, 3] - P1[0, 3] },
            { point1[1] * P1[2, 0] - P1[1, 0], point1[1] * P1[2, 1] - P1[1, 1], point1[1] * P1[2, 2] - P1[1, 2], point1[1] * P1[2, 3] - P1[1, 3] },
            { point2[0] * P2[2, 0] - P2[0, 0], point2[0] * P2[2, 1] - P2[0, 1], point2[0] * P2[2, 2] - P2[0, 2], point2[0] * P2[2, 3] - P2[0, 3] },
            { point2[1] * P2[2, 0] - P2[1, 0], point2[1] * P2[2, 1] - P2[1, 1], point2[1] * P2[2, 2] - P2[1, 2], point2[1] * P2[2, 3] - P2[1, 3] }
        });

        // Perform SVD on A
        var svd = A.Svd(true);

        // Solution is the last column of V (corresponding to the smallest singular value)
        Vector<double> X = svd.VT.Row(svd.VT.RowCount - 1);
        //Debug.Log("Solution: " + X[0] + ", " + X[1] + ", " + X[2] + ", " + X[3]);
        Vector3 estimatedPos = new Vector3((float)(X[0] / X[3]), (float)(X[1] / X[3]), (float)(X[2] / X[3]));

        //estimated position is in C1 coordiates
        // need inverse of c1 extrinsic parameters and apply it to estimated pos
        Quaternion q = c1.transform.rotation;
        Vector3 t = c1.transform.position;
        //construct extrinsic matrix relative to world
        //invert it
        //multiply esimated position by that 

        Vector3 worldPos = c1.transform.position - estimatedPos;
        worldPos.z = estimatedPos.z;
        //Debug.Log("Actual Position: " + target.transform.position
        //    + " | Camera 1 position: " + c1.transform.position
        //    + " | Camera 2 position: " + c2.transform.position
        //    + " | Estimated Position: " + estimatedPos
        //    + " | Relative to C2:" + (c2.transform.position + estimatedPos) );



        return estimatedPos;
    }


    public (Matrix<double>, Vector<double>) ExtractRT(Camera camera)
    {
        // Extract translation vector T
        Vector3 position = camera.transform.position;
        Vector<double> T = DenseVector.OfArray(new double[] { position.x, position.y, position.z });

        // Extract rotation matrix R
        Quaternion rotation = camera.transform.rotation;
        Matrix<double> R = QuaternionToMatrix2(rotation);

        return (R, T);
    }

    Matrix<double> QuaternionToMatrix(Quaternion q)
    {
        Matrix<double> R = DenseMatrix.OfArray(new double[,]
        {
            { 1 - 2*q.y*q.y - 2*q.z*q.z, 2*q.x*q.y - 2*q.z*q.w, 2*q.x*q.z + 2*q.y*q.w },
            { 2*q.x*q.y + 2*q.z*q.w, 1 - 2*q.x*q.x - 2*q.z*q.z, 2*q.y*q.z - 2*q.x*q.w },
            { 2*q.x*q.z - 2*q.y*q.w, 2*q.y*q.z + 2*q.x*q.w, 1 - 2*q.x*q.x - 2*q.y*q.y }
        });

        return R;
    }
    Matrix<double> QuaternionToMatrix2(Quaternion q)
    {
        float q0 = q.x;
        float q1 = q.y;
        float q2 = q.z;
        float q3 = q.w;

        // First row of the rotation matrix
        float r00 = 2 * (q0 * q0 + q1 * q1) - 1;
        float r01 = 2 * (q1 * q2 - q0 * q3);
        float r02 = 2 * (q1 * q3 + q0 * q2);

        // Second row of the rotation matrix
        float r10 = 2 * (q1 * q2 + q0 * q3);
        float r11 = 2 * (q0 * q0 + q2 * q2) - 1;
        float r12 = 2 * (q2 * q3 - q0 * q1);

        //# Third row of the rotation matrix
        float r20 = 2 * (q1 * q3 - q0 * q2);
        float r21 = 2 * (q2 * q3 + q0 * q1);
        float r22 = 2 * (q0 * q0 + q3 * q3) - 1;
        Matrix<double> R = DenseMatrix.OfArray(new double[,]
        {
            { r00, r01, r02 },
            { r10, r11, r12 },
            { r20, r21, r22 }
        });

        return R;
    }


    Matrix<double> GetProjectionMatrix(Camera c)
    {
        Matrix4x4 p = c.projectionMatrix;
        Matrix<double> P = Matrix<double>.Build.Dense(4, 4);

        for (int i = 0; i < 4; i++)
        {
            for (int j = 0; j < 4; j++)
            {
                P[i, j] = p[i, j];
            }
        }

        return P;

    }
}
