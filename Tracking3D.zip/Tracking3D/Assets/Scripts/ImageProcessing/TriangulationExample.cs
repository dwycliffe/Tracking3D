using UnityEngine;
using MathNet.Numerics.LinearAlgebra;
using MathNet.Numerics.LinearAlgebra.Double;

public class TriangulationExample : MonoBehaviour
{
    // Intrinsic parameters for camera 1
    double fx1 = 800; // Example value
    double fy1 = 800; // Example value
    double cx1 = 640; // Example value
    double cy1 = 480; // Example value

    // Intrinsic parameters for camera 2
    double fx2 = 800; // Example value
    double fy2 = 800; // Example value
    double cx2 = 640; // Example value
    double cy2 = 480; // Example value

    // Extrinsic parameters (rotation and translation) for camera 2 relative to camera 1
    Matrix<double> R = DenseMatrix.OfArray(new double[,]
    {
        { 1, 0, 0 },
        { 0, 1, 0 },
        { 0, 0, 1 }
    }); // Example rotation matrix

    Vector<double> T = DenseVector.OfArray(new double[] { 1, 0, 0 }); // Example translation vector

    void Start()
    {
        // Example 2D points in the two images
        Vector<double> point1 = DenseVector.OfArray(new double[] { 500, 400 });
        Vector<double> point2 = DenseVector.OfArray(new double[] { 520, 410 });

        // Perform triangulation
        Vector<double> point3D = TriangulatePoint(point1, point2);

        Debug.Log("3D Point: " + point3D);
    }

    Vector<double> TriangulatePoint(Vector<double> point1, Vector<double> point2)
    {
        // Intrinsic matrices
        Matrix<double> K1 = DenseMatrix.OfArray(new double[,]
        {
            { fx1, 0, cx1 },
            { 0, fy1, cy1 },
            { 0, 0, 1 }
        });

        Matrix<double> K2 = DenseMatrix.OfArray(new double[,]
        {
            { fx2, 0, cx2 },
            { 0, fy2, cy2 },
            { 0, 0, 1 }
        });

        // Projection matrices
        Matrix<double> P1 = K1 * DenseMatrix.OfArray(new double[,]
        {
            { 1, 0, 0, 0 },
            { 0, 1, 0, 0 },
            { 0, 0, 1, 0 }
        });

        Matrix<double> P2 = K2 * DenseMatrix.OfArray(new double[,]
        {
            { R[0, 0], R[0, 1], R[0, 2], T[0] },
            { R[1, 0], R[1, 1], R[1, 2], T[1] },
            { R[2, 0], R[2, 1], R[2, 2], T[2] }
        });

        // Construct the A matrix
        Matrix<double> A = DenseMatrix.OfArray(new double[,]
        {
            { point1[0] * P1[2, 0] - P1[0, 0], point1[0] * P1[2, 1] - P1[0, 1], point1[0] * P1[2, 2] - P1[0, 2], point1[0] * P1[2, 3] - P1[0, 3] },
            { point1[1] * P1[2, 0] - P1[1, 0], point1[1] * P1[2, 1] - P1[1, 1], point1[1] * P1[2, 2] - P1[1, 2], point1[1] * P1[2, 3] - P1[1, 3] },
            { point2[0] * P2[2, 0] - P2[0, 0], point2[0] * P2[2, 1] - P2[0, 1], point2[0] * P2[2, 2] - P2[0, 2], point2[0] * P2[2, 3] - P2[0, 3] },
            { point2[1] * P2[2, 0] - P2[1, 0], point2[1] * P2[2, 1] - P2[1, 1], point2[1] * P2[2, 2] - P2[1, 2], point2[1] * P2[2, 3] - P2[1, 3] }
        });

        // Perform SVD on A
        var svd = A.Svd(true);

        // Solution is the last column of V (corresponding to the smallest singular value)
        Vector<double> X = svd.VT.Row(svd.VT.RowCount - 1);

        // Convert from homogeneous coordinates to 3D coordinates
        return X.SubVector(0, 3) / X[3];
    }
}
