using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PredictionManager : MonoBehaviour
{
    //Tracking start and interval logic
    public bool startTracking = false;
    float timer = 0f;
    float interval = 1f;

    //Estimate GOs 
    public GameObject estimateParent;
    public List<GameObject> estimates = new List<GameObject>();
    //public Dictionary<string, GameObject> esimates = new Dictionary<string, GameObject>();
    public GameObject estimagePrefab;

    //Environment turned off during imaging
    public GameObject environmentParent;

    //Processing
    public CameraManager cameraManager;
    public ImageProcessing imageProcessor;

    // Start is called before the first frame update
    void Start()
    {
        cameraManager.UpdateCameraList();
        CreateEstimates();
    }

    // Update is called once per frame
    void Update()
    {
        timer += Time.deltaTime;
        if(timer >= interval && startTracking)
        {
            Track();
            timer = 0f;
        }
    }

    public void Track()
    {
        //hide estimates to avoid interference with mask estimation
        estimateParent.SetActive(false);
        environmentParent.SetActive(false);

        //take pics
        cameraManager.TakePictures();

        //make estimates
        imageProcessor.ProcessCameraImages();

        //update estimates and set to visible
        UpdateEstimates();
        estimateParent.SetActive(true);
        environmentParent.SetActive(true);
    }

    public void UpdateEstimates()
    {
      
        foreach (GameObject estimate in estimates)
        {
            if (imageProcessor.estimates.ContainsKey(estimate.name))
            {
                estimate.SetActive(true);
                estimate.transform.position = imageProcessor.estimates[estimate.name];
                //estimate.transform.LookAt(Camera.main.transform);
                
                //Debug.Log("Set Estimate: " + estimate.name + " to prediction:" + imageProcessor.estimates[estimate.name]);
            }
            else
            {
                estimate.SetActive(false);
            }

        }
    }

    public void CreateEstimates()
    {
        for (int i = 1; i < cameraManager.cameras.Count; i++)
        {
            Camera c1 = cameraManager.cameras[i - 1];
            Camera c2 = cameraManager.cameras[i];
            GameObject estimate = Instantiate(estimagePrefab, Vector3.zero, Quaternion.identity);
            estimate.GetComponent<EstimateManager>().SetName("RAY_" + c1.name + "_" + c2.name);
            estimate.transform.SetParent(estimateParent.transform);
            estimates.Add(estimate);
        }


    }
}
