using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PredictionManager : MonoBehaviour
{
    //Tracking start and interval logic
    public bool startTracking = false;
    float timer = 0f;
    float interval = 1f;

    //Estimate GOs 
    public GameObject estimateParent;
    //public List<GameObject> estimates = new List<GameObject>();
    public Dictionary<string, GameObject> estimates = new Dictionary<string, GameObject>();
    public GameObject estimagePrefab;
    public GameObject estimateAverage;

    //Environment turned off during imaging
    public GameObject environmentParent;

    //Processing
    public CameraManager cameraManager;
    public ImageProcessing imageProcessor;

    // Start is called before the first frame update
    void Start()
    {
        cameraManager.UpdateCameraList();
        CreateEstimates();
        
    }

    // Update is called once per frame
    void Update()
    {
        timer += Time.deltaTime;
        if(timer >= interval && startTracking)
        {
            Track();
            timer = 0f;
        }
    }

    public void Track()
    {
        //hide estimates to avoid interference with mask estimation
        estimateParent.SetActive(false);
        environmentParent.SetActive(false);

        //take pics
        cameraManager.TakePictures();

        //make estimates
        imageProcessor.ProcessCameraImages();

        //update estimates and set to visible
        UpdateEstimates();
        estimateParent.SetActive(true);
        environmentParent.SetActive(true);
    }

    public void UpdateEstimates()
    {
        //If multiple camera estimates, average them together and display one
        if(imageProcessor.estimates.Count > 1)
        {
            ToggleAllEstimates(false);
            estimateAverage.SetActive(true);
            estimateAverage.GetComponent<EstimateManager>().SetName("AVG of " + imageProcessor.estimates.Count);
            Vector3 avg = Vector3.zero;
            foreach (KeyValuePair<string, Vector3> kvp in imageProcessor.estimates)
            {
                avg += kvp.Value;
            }
            avg /= imageProcessor.estimates.Count;

            estimateAverage.transform.position = avg;
        }
        else if (imageProcessor.estimates.Count == 1)
        {
            //Display the specific camera estimate
            estimateAverage.SetActive(false);
            ToggleAllEstimates(false);
            foreach (string key in imageProcessor.estimates.Keys)
            {
                estimates[key].SetActive(true);
                estimates[key].transform.position = imageProcessor.estimates[key];
            }
        }
        else
        {
            //Hide everything if no estimates
            estimateAverage.SetActive(false);
            ToggleAllEstimates(false);

        }
        //foreach (GameObject estimate in estimates)
        //{
        //    if (imageProcessor.estimates.ContainsKey(estimate.name))
        //    {
        //        estimate.SetActive(true);
        //        estimate.transform.position = imageProcessor.estimates[estimate.name];
        //        //estimate.transform.LookAt(Camera.main.transform);
                
        //        //Debug.Log("Set Estimate: " + estimate.name + " to prediction:" + imageProcessor.estimates[estimate.name]);
        //    }
        //    else
        //    {
        //        estimate.SetActive(false);
        //    }

        //}
    }

    public void ToggleAllEstimates(bool active)
    {
        foreach (GameObject estimate in estimates.Values)
        {
            estimate.SetActive(active);
        }
    }
    public void CreateEstimates()
    {
        for (int i = 1; i < cameraManager.cameras.Count; i++)
        {
            Camera c1 = cameraManager.cameras[i - 1];
            Camera c2 = cameraManager.cameras[i];
            GameObject estimate = Instantiate(estimagePrefab, Vector3.zero, Quaternion.identity);
            estimate.GetComponent<EstimateManager>().SetName(c1.name + "_" + c2.name);
            estimate.transform.SetParent(estimateParent.transform);
            estimates[estimate.name] = estimate;
        }


    }
}
